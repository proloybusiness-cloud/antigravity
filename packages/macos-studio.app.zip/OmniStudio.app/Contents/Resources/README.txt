OmniStudio 1.0.0
Bundle: com.omnios.macos.studio
